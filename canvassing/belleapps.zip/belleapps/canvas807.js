window.onload = resizing;
window.onresize = resizing;

function resizing() {
var wid = window.innerWidth;
var hi = window.innerHeight;

var lstr = wid/2 - 40;
var rstr = wid/2 + 40;

drawCanvas(wid, hi);

var midwid = wid/2;

drawIcons(midwid);

}

// must redraw function when screen size changes

var wid = window.innerWidth;
var hi = window.innerHeight;

function drawCanvas(wid, hi) {

var canvas = document.getElementById('map');
var context = canvas.getContext('2d');

canvas.width = window.innerWidth;
canvas.height = $('#diagram').height();

/** Create lines that connect to each other by
 * saving the endpoint of one and making it the
 * starting point of the next.
 **/

var m = wid*.1;
var n = 80;

var o = '#fa7e00';
var b = '#00ada7';
var w = "#ffffff";

function save(a, b) {
    // saves numbers set for a and b
    m = a
    n = b
}

function connector(x, y, color) {
    // x and y are numbers
    context.beginPath();
    context.strokeStyle = color;
    context.lineWidth = 5;
    context.lineCap = 'round';
    context.moveTo(m, n);
    context.lineTo(x, y);
    save(x, y);
    context.stroke();
}

/* Create backing labels for text */
function labelBack(x, y, x1, y1, color) {
    // x and y are numbers to determine lineTo
    // color is a string for a hexcode
    context.beginPath();
    context.moveTo(x, y);
    context.lineTo(x1, y1);
    context.lineWidth = 50;
    context.strokeStyle = color;
    context.lineCap = 'round';
    context.stroke();
}

/* Create standard text */
function label(t, x, y, color, s) {
    // t is a string. x and y are numbers
    context.fillStyle = color;
    context.font = s.toString()+"px Montserrat";
    context.fillText(t, x, y);
}

// START LEFT LINE

var s = 30;
var lstr = wid/2 - 40;
var rstr = wid/2 + 40;

// h1
connector(lstr,80, o);
label("You're hungry...", m-270, n+40, o, s);

// v1
connector(lstr,800);

// h2
labelBack(lstr, 800,140, 800);
connector(lstr-140, 810);
label('Place a request', lstr-240, 808, w, s);

// v2
connector(lstr-140, 180*10);

// h3
labelBack(lstr, 1800,lstr-300, 1800);
connector(lstr, 180*10);
label('See your deliverer', lstr-300, 1808, w, s);

// v3
connector(lstr, 320*10);

// h4
label("You're happy", lstr-220, n+40, o, s);
connector(wid*.1, 320*10);

// END LEFT LINE



// START RIGHT LINE

save(wid*.9, 80);

// h1
label("You're out shopping...", rstr+20, n+40, b, 30);
connector(rstr, 80, b);

// v1
connector(rstr, 500);

// h2
connector(rstr+80, 500);

// v2
connector(rstr+80, 110*10);

// h3
connector(rstr, 110*10);

// v3
labelBack(rstr-100,110*10, rstr+200, 110*10);
connector(rstr, 150*10);
label("Find the request", rstr-100, 1100+8, w, s);

// h4
labelBack(rstr+300, 150*10, rstr,150*10);
connector(rstr+300, 150*10);
label("Accept delivery", rstr, 1500+8, w, s);

//context.bezierCurveTo(400, 250, 500, 300, 400, 400);

// v4
connector(rstr+300, 155*10);

//context.bezierCurveTo(400, 420, 200, 400, 350, 600);

// d1
connector(rstr+224, 172*10);

// d2
connector(rstr, 190*10);

// v5
connector(rstr, 320*10);

// h5
label("You're happy", rstr+20, n+40, b, s);
connector(wid*.9, 320*10);

// END RIGHT LINE

label("BECAUSE YOUR FRIENDS ARE SHOPPERS TOO", 60, n+300, w, 42);

};

// see canvas js file to call drawIcons

var midwid = wid/2;
function drawIcons(midwid){

// keep in mind that mobile responsiveness starts at 700px wide

var p1 = (midwid-350);

p1.toString()+"px"
document.getElementById("studying").style.left = "10%";
document.getElementById("studying").style.top = "130px";

document.getElementById("shopping").style.right = "10%";
document.getElementById("shopping").style.top = "130px";

var l2 = (midwid-100);
document.getElementById("logo").style.left = l2.toString()+"px";
document.getElementById("logo").style.top = "700px";

document.getElementById("list").style.left = "15%";
document.getElementById("list").style.top = "1100px";

var e3 = (midwid-300);
document.getElementById("earn").style.right = e3.toString()+"px";
document.getElementById("earn").style.top = "1400px";

var r4 = (midwid-300);
document.getElementById("route").style.right = r4.toString()+"px";
document.getElementById("route").style.top = "1800px";

var m5 = (midwid-300);
document.getElementById("miles").style.left = m5.toString()+"px";
document.getElementById("miles").style.top = "2100px";

var c6 = (midwid-100);
document.getElementById("circle").style.left = c6.toString()+"px";
document.getElementById("circle").style.top = "2600px";

var r7 = (midwid-100);
document.getElementById("receipt").style.left = r7.toString()+"px";
document.getElementById("receipt").style.top = "2800px";

var f8 = (midwid-300);
document.getElementById("food").style.left = "10%";
document.getElementById("food").style.top = "3260px";

var m9 = (midwid-290);
document.getElementById("money").style.right = "10%";
document.getElementById("money").style.top = "3300px";



}